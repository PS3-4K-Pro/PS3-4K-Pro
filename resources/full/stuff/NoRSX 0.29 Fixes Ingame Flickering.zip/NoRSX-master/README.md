NoRSX is a 2D lib for PSL1GHT
=============================

This lib will be installed inside the PORTLIBS

Authors
-------
	deroad
	kakaroto (for his rsxutil.c)
	KDSBest (for some performance patches)

Homebrews built with this lib:
------------------------------
	NoRSX Example  (deroad)
	PS Seismograph (deroad)
	XMB Manager Plus (XMBM+ Team)


Fonts
-----

All the fonts included with the example aren't mine..
 
